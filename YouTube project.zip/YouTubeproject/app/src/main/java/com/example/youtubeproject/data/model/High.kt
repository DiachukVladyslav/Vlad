package com.example.youtubeproject.data.model

data class High(
    val height: Int,
    val url: String,
    val width: Int
)