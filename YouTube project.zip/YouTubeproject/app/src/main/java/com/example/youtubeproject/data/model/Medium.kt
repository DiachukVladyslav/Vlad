package com.example.youtubeproject.data.model

data class Medium(
    val height: Int,
    val url: String,
    val width: Int
)