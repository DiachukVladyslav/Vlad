package com.example.youtubeproject.data.model

data class Thumbnails(
    val default: Default,
    val high: High,
    val medium: Medium
)