package com.example.youtubeproject.data.model

data class PageInfo(
    val resultsPerPage: Int,
    val totalResults: Int
)