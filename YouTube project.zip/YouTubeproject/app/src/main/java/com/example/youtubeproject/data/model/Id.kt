package com.example.youtubeproject.data.model

data class Id(
    val channelId: String,
    val kind: String,
    val videoId: String
)