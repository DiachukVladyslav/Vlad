package com.example.youtubeproject.data.model

data class Default(
    val height: Int,
    val url: String,
    val width: Int
)